/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package braingame;
import java.net.*;
import java.io.*;
/**
 *
 * @author Malware
 */
public class ClientHandler extends Thread{
    Socket client;
    PrintWriter out;
    BufferedReader in;
    ClientHandler(Socket sc)
    {
        client = sc;
    }
    public void run()
    {
        try
        {
            out = new PrintWriter(client.getOutputStream());
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));
            while(true)
            {
                
                sleep(1000);
            }
        }
        catch(Exception e)
        {
            
        }
    }
}
