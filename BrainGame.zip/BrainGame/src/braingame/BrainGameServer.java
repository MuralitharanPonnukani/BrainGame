/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package braingame;
import java.net.*;
import java.io.*;
public class BrainGameServer extends Thread{
    private final ServerSocket server;
    private Socket client;
    public BrainGameServer() throws Exception
    {
        server = new ServerSocket(3333);
        start();
    }
    
    @Override
    public void run()
    {
        try
        {
            while(true)
            {
                client = server.accept();
                sleep(200);
            }
        }
        catch(IOException e)
        { 
            
        }
        catch(InterruptedException e)
        {
            
        }
    }
    
}