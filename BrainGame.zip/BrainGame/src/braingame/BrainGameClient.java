package braingame;
import java.net.*;
import java.io.*;
public class BrainGameClient extends Thread{
	Socket client;
	public BrainGameClient() throws Exception
	{
		client = new Socket("127.0.0.1",3333);
		start();
	}
	public void run()
	{
            try
            {
                while(true)
                {
                    sleep(1000);
                }
            }
            catch(Exception e)
            {
                System.out.println(e);
            }
	}
	public static void main(String args[])
	{
		try
		{
			new BrainGameClient();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
